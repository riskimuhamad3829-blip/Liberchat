import React, { useState, useEffect, useRef } from 'react';
import { Socket } from 'socket.io-client';
import { Send, UserCircle2, ShieldCheck } from 'lucide-react';

interface ChatProps {
  phoneNumber: string;
  socket: Socket;
}

interface User {
  number: string;
  online: boolean;
}

interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
}

const Chat: React.FC<ChatProps> = ({ phoneNumber, socket }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fungsi Auto-Scroll ke bawah
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Sinkronisasi status online kontak
    socket.on('users_update', (updatedUsers: User[]) => {
      setUsers(updatedUsers);
    });

    // Mengambil riwayat pesan lama
    socket.on('messages_history', (history: Message[]) => {
      setMessages(history);
      setTimeout(scrollToBottom, 150);
    });

    // Menerima pesan baru secara langsung
    socket.on('new_message', (msg: Message) => {
      setMessages((prev) => [...prev, msg]);
      setTimeout(scrollToBottom, 150);
    });

    return () => {
      socket.off('users_update');
      socket.off('messages_history');
      socket.off('new_message');
    };
  }, [socket]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    socket.emit('send_message', inputText.trim());
    setInputText('');
  };

  return (
    <div className="w-full max-w-5xl h-[85vh] bg-slate-900 border border-slate-700 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.5)] flex overflow-hidden animate-fade-in">
      
      {/* Sidebar Kiri - Daftar Kontak Nokos */}
      <div className="w-1/3 bg-slate-800/80 border-r border-slate-700 flex flex-col">
        <div className="p-5 bg-slate-800 border-b border-slate-700 flex flex-col justify-center">
          <h2 className="text-xl font-bold text-white flex items-center">
            <UserCircle2 className="mr-2 text-blue-400" /> Profil Nokos
          </h2>
          <p className="text-sm font-mono text-slate-400 mt-1 pl-8">{phoneNumber}</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          <p className="text-xs font-semibold text-slate-500 uppercase px-2 mb-3 mt-1">Daftar Pengguna Server</p>
          {users.map((u) => (
            <div key={u.number} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl hover:bg-slate-700/60 transition-colors border border-transparent hover:border-slate-600">
              <span className="font-mono text-sm text-slate-200">
                {u.number === phoneNumber ? `${u.number} (Anda)` : u.number}
              </span>
              <div className="flex items-center">
                <span className="text-[10px] text-slate-400 mr-2">{u.online ? 'Online' : 'Offline'}</span>
                <div className={`w-2.5 h-2.5 rounded-full shadow-lg ${u.online ? "bg-green-500 shadow-green-500/50" : "bg-slate-500"}`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ruang Chat Utama */}
      <div className="flex-1 flex flex-col bg-slate-900/95 relative">
        <div className="px-6 py-4 bg-slate-800/90 border-b border-slate-700 backdrop-blur-md z-10 flex justify-between items-center">
          <div>
            <h3 className="font-semibold text-white text-lg">Global Room</h3>
            <p className="text-xs text-green-400 flex items-center mt-1 font-mono">
              <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
              Enkripsi End-to-End Aktif
            </p>
          </div>
          <ShieldCheck className="text-slate-500" size={24} />
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {messages.length === 0 && (
            <div className="text-center text-slate-500 text-sm mt-10">Belum ada pesan. Jadilah yang pertama!</div>
          )}
          {messages.map((msg) => {
            const isMe = msg.sender === phoneNumber;
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <span className="text-xs text-slate-400 font-mono mb-1 mx-2">
                  {isMe ? 'Anda' : msg.sender}
                </span>
                <div className={`px-5 py-3 rounded-2xl max-w-[80%] shadow-md ${isMe ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-slate-700 text-white rounded-tl-sm'}`}>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 mx-2">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })}
          <div ref={messagesEndRef} className="h-1" />
        </div>

        {/* Input Text Form */}
        <div className="p-4 bg-slate-800/90 border-t border-slate-700 backdrop-blur-md">
          <form onSubmit={handleSend} className="flex gap-3">
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Kirim pesan anonim..." 
              autoComplete="off"
              className="flex-1 bg-slate-900 border border-slate-600 rounded-full px-6 py-3.5 text-sm text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all shadow-inner"
            />
            <button 
              type="submit"
              disabled={!inputText.trim()}
              className="bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-400 hover:to-indigo-500 disabled:opacity-50 text-white rounded-full h-[50px] w-[50px] flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all active:scale-95"
            >
              <Send size={20} className="ml-1" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Chat;
