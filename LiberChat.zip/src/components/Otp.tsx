import React, { useState, useEffect } from 'react';
import { Terminal, KeyRound } from 'lucide-react';

interface OtpProps {
  phoneNumber: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const Otp: React.FC<OtpProps> = ({ phoneNumber, onSuccess, onCancel }) => {
  const [countdown, setCountdown] = useState(60);
  const [otpCode, setOtpCode] = useState<string | null>(null);
  const [inputCode, setInputCode] = useState('');
  const [error, setError] = useState('');

  // Countdown timer (60 detik) dan Injeksi OTP palsu (5 detik)
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    const otpTimer = setTimeout(() => {
      const code = Math.floor(10000 + Math.random() * 90000).toString();
      setOtpCode(code);
    }, 5000);

    return () => {
      clearInterval(timer);
      clearTimeout(otpTimer);
    };
  }, []);

  const handleVerify = () => {
    if (inputCode === otpCode) {
      onSuccess();
    } else {
      setError('Akses Ditolak: Kode OTP Tidak Valid!');
      setInputCode('');
    }
  };

  return (
    <div className="w-full max-w-md bg-slate-800/60 backdrop-blur-xl p-8 rounded-2xl border border-slate-700 shadow-2xl animate-fade-in">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">Verifikasi Sinyal</h2>
        <p className="text-slate-400 text-sm">Menunggu intersepsi OTP untuk Nokos: <br/><span className="font-mono text-blue-400 font-bold tracking-wider mt-1 inline-block">{phoneNumber}</span></p>
      </div>

      {/* Terminal Intersepsi GSM */}
      <div className="bg-black/80 border border-green-500/30 shadow-[0_0_10px_rgba(34,197,94,0.1)_inset] rounded-lg p-4 font-mono text-xs sm:text-sm mb-6 h-36 flex flex-col justify-end overflow-hidden relative">
        <div className="text-green-500/80 mb-1 flex items-center"><Terminal size={14} className="mr-2"/> Menghubungkan ke menara terdekat...</div>
        <div className="text-green-500/80 mb-1">Bypass protokol SMS... <span className="text-white">Timeout: {countdown}s</span></div>
        {otpCode ? (
          <div className="text-green-400 font-bold mt-2 animate-pulse bg-green-500/10 p-1 border-l-2 border-green-500">
            [+] PESAN DITEMUKAN: OTP ANDA ADALAH {otpCode}
          </div>
        ) : (
          <div className="text-yellow-500/80 mt-2 animate-pulse">
            [*] Menunggu paket data masuk...
          </div>
        )}
      </div>

      <div className="space-y-4">
        {error && <p className="text-red-400 text-sm text-center font-medium animate-pulse">{error}</p>}
        
        <div className="relative">
          <KeyRound className="absolute left-3 top-3.5 text-slate-500" size={18} />
          <input 
            type="text" 
            placeholder="Masukkan 5 digit OTP"
            maxLength={5}
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value.replace(/\D/g, ''))}
            className="w-full bg-slate-900/80 border border-slate-600 rounded-lg pl-10 pr-4 py-3 text-white text-center tracking-widest font-mono text-xl focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition-colors"
          />
        </div>

        <button 
          onClick={handleVerify}
          disabled={inputCode.length !== 5}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-bold py-3.5 px-4 rounded-lg shadow-[0_0_15px_rgba(34,197,94,0.4)] transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:active:scale-100"
        >
          Masuk ke Jaringan Aman
        </button>

        <button 
          onClick={onCancel}
          className="w-full text-slate-400 hover:text-white text-sm py-2 transition-colors"
        >
          Batalkan & Ganti Nomor
        </button>
      </div>
    </div>
  );
};

export default Otp;
