import React, { useState } from 'react';
import { Smartphone, ShieldAlert, Loader2 } from 'lucide-react';

interface LoginProps {
  onSuccess: (number: string) => void;
}

const Login: React.FC<LoginProps> = ({ onSuccess }) => {
  const [countryCode, setCountryCode] = useState('+1');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generateNumber = async () => {
    setLoading(true);
    setError('');
    
    // Generate nomor acak 7 digit
    const randomNum = Math.floor(1000000 + Math.random() * 9000000);
    const fullNumber = `${countryCode}-${randomNum}`;
    
    try {
      // Memanggil API backend untuk pengecekan Collision Error
      const res = await fetch('/api/check-number', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: fullNumber })
      });
      
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Terjadi kesalahan sistem.');
      }
      
      // Simulasi penundaan pencarian sinyal
      setTimeout(() => {
        onSuccess(fullNumber);
      }, 1500);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md bg-slate-800/60 backdrop-blur-xl p-8 rounded-2xl border border-slate-700 shadow-2xl animate-fade-in transition-all duration-300">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500/10 text-blue-400 rounded-full mb-4 shadow-[0_0_20px_rgba(59,130,246,0.3)]">
          <ShieldAlert size={32} />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-400">
          LiberChat
        </h1>
        <p className="text-slate-400 mt-2 text-sm">Pabrik Nokos (Nomor Kosong) - Anonimitas Total</p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 text-red-400 rounded-lg text-sm text-center animate-pulse">
          {error}
        </div>
      )}

      <div className="space-y-5">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Pilih Gateway Negara</label>
          <select 
            value={countryCode}
            onChange={(e) => setCountryCode(e.target.value)}
            className="w-full bg-slate-900/80 border border-slate-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 appearance-none"
          >
            <option value="+1">🇺🇸 United States (+1)</option>
            <option value="+44">🇬🇧 United Kingdom (+44)</option>
            <option value="+7">🇷🇺 Russia (+7)</option>
            <option value="+62">🇮🇩 Indonesia (+62) - Proxy</option>
          </select>
        </div>

        <button 
          onClick={generateNumber}
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold py-3.5 px-4 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.4)] transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100"
        >
          {loading ? (
            <Loader2 className="animate-spin mr-2" size={20} />
          ) : (
            <Smartphone className="mr-2" size={20} />
          )}
          {loading ? 'Mencetak Nomor...' : 'Buat Nokos Sekarang'}
        </button>
      </div>
    </div>
  );
};

export default Login;
