import React, { useState } from 'react';
import Login from './components/Login';
import Otp from './components/Otp';
import Chat from './components/Chat';
import { Socket, io } from 'socket.io-client';

export type AppState = 'LOGIN' | 'OTP' | 'CHAT';

// Otomatis terhubung ke domain saat ini (Kompatibel dengan Glitch)
const socketUrl = window.location.origin;
export const socket: Socket = io(socketUrl, { autoConnect: false });

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('LOGIN');
  const [phoneNumber, setPhoneNumber] = useState('');

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {appState === 'LOGIN' && (
        <Login 
          onSuccess={(number) => {
            setPhoneNumber(number);
            setAppState('OTP');
          }} 
        />
      )}
      {appState === 'OTP' && (
        <Otp 
          phoneNumber={phoneNumber} 
          onSuccess={() => {
            socket.connect();
            socket.emit('login', phoneNumber);
            setAppState('CHAT');
          }}
          onCancel={() => setAppState('LOGIN')}
        />
      )}
      {appState === 'CHAT' && (
        <Chat phoneNumber={phoneNumber} socket={socket} />
      )}
    </div>
  );
};

export default App;
