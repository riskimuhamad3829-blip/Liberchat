import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' }
});

// Menggunakan /tmp agar tidak Crash/Error 500 di Vercel (Read-Only System)
const DB_FILE = '/tmp/database.json';

// In-memory cache & Database
let db = { users: {}, messages: [] };

function loadDb() {
  if (fs.existsSync(DB_FILE)) {
    try {
      db = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
      // Reset status online saat server restart
      Object.keys(db.users).forEach(num => {
        db.users[num].online = false;
      });
    } catch (e) {
      console.error("Error membaca DB", e);
    }
  } else {
    saveDb();
  }
}

function saveDb() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

loadDb();

app.use(express.static(path.join(__dirname, 'dist')));
app.use(express.json());

// API: Cek ketersediaan nomor & penanganan tabrakan (Collision)
app.post('/api/check-number', (req, res) => {
  const { number } = req.body;
  if (db.users[number]) {
    return res.status(400).json({ error: 'Nomor sudah terdaftar! Sistem mendeteksi tabrakan Nokos.' });
  }
  res.json({ success: true });
});

// Real-time Socket.io
io.on('connection', (socket) => {
  let currentUser = null;

  socket.on('login', (number) => {
    currentUser = number;
    if (!db.users[number]) {
      db.users[number] = { number, online: true, socketId: socket.id };
    } else {
      db.users[number].online = true;
      db.users[number].socketId = socket.id;
    }
    saveDb();
    
    // Broadcast status online ke semua pengguna
    io.emit('users_update', Object.values(db.users));
    // Kirim riwayat pesan ke user yang baru masuk
    socket.emit('messages_history', db.messages);
  });

  socket.on('send_message', (text) => {
    if (!currentUser) return;
    const msg = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      sender: currentUser,
      text,
      timestamp: new Date().toISOString()
    };
    db.messages.push(msg);
    saveDb();
    io.emit('new_message', msg);
  });

  socket.on('disconnect', () => {
    if (currentUser && db.users[currentUser]) {
      db.users[currentUser].online = false;
      saveDb();
      io.emit('users_update', Object.values(db.users));
    }
  });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`LiberChat Server berjalan di port ${PORT}`);
});
