// LiberChat uses in-memory storage, not PostgreSQL.
// This file is kept for compatibility but does nothing.
// See src/lib/store.ts for the actual data store.

export const db = null;
export const pool = null;
