// ============================================================
// LiberChat - In-Memory Data Store
// All data lives in RAM. No external DB needed.
// ============================================================

export interface User {
  id: string;
  phone: string;       // e.g. "+6281234567890"
  name: string;
  avatar: string;
  createdAt: number;
}

export interface OTPRecord {
  phone: string;
  otp: string;
  expiresAt: number;   // epoch ms
  verified: boolean;
}

export interface Contact {
  ownerId: string;     // user who owns this contact list
  contactId: string;  // user being followed
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
  status: "sent" | "delivered" | "read";
}

// ── Singleton in-memory store ───────────────────────────────
const globalStore = globalThis as typeof globalThis & {
  __liberChat?: {
    users: Map<string, User>;         // userId  → User
    phones: Map<string, string>;      // phone   → userId
    otps: Map<string, OTPRecord>;     // phone   → OTPRecord
    contacts: Contact[];
    messages: Message[];
    socketMap: Map<string, string>;   // userId  → socketId  (managed server-side)
  };
};

if (!globalStore.__liberChat) {
  globalStore.__liberChat = {
    users: new Map(),
    phones: new Map(),
    otps: new Map(),
    contacts: [],
    messages: [],
    socketMap: new Map(),
  };

  // ── Seed demo users ─────────────────────────────────────
  const seed: User[] = [
    {
      id: "demo-001",
      phone: "+6281111111111",
      name: "Alice (Demo)",
      avatar: "/default-avatar.png",
      createdAt: Date.now(),
    },
    {
      id: "demo-002",
      phone: "+6282222222222",
      name: "Bob (Demo)",
      avatar: "/default-avatar.png",
      createdAt: Date.now(),
    },
    {
      id: "demo-003",
      phone: "+6283333333333",
      name: "Charlie (Demo)",
      avatar: "/default-avatar.png",
      createdAt: Date.now(),
    },
  ];

  for (const u of seed) {
    globalStore.__liberChat.users.set(u.id, u);
    globalStore.__liberChat.phones.set(u.phone, u.id);
  }

  // Seed contacts: demo-001 ↔ demo-002, demo-001 ↔ demo-003
  globalStore.__liberChat.contacts.push(
    { ownerId: "demo-001", contactId: "demo-002" },
    { ownerId: "demo-001", contactId: "demo-003" },
    { ownerId: "demo-002", contactId: "demo-001" },
    { ownerId: "demo-003", contactId: "demo-001" },
  );

  // Seed messages
  const now = Date.now();
  globalStore.__liberChat.messages.push(
    {
      id: "msg-001",
      senderId: "demo-002",
      receiverId: "demo-001",
      content: "Halo! Ini Alice ya? 👋",
      timestamp: now - 3600_000,
      status: "read",
    },
    {
      id: "msg-002",
      senderId: "demo-001",
      receiverId: "demo-002",
      content: "Iya bener! Halo Bob! 😊",
      timestamp: now - 3500_000,
      status: "read",
    },
    {
      id: "msg-003",
      senderId: "demo-002",
      receiverId: "demo-001",
      content: "Udah coba LiberChat belum? Fiturnya mirip WA lho!",
      timestamp: now - 1800_000,
      status: "delivered",
    },
  );
}

export const store = globalStore.__liberChat!;
