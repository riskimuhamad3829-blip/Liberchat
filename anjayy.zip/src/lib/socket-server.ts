// ============================================================
// LiberChat - Socket.io Server Singleton
// Attaches once to the Next.js HTTP server.
// ============================================================
import { Server as SocketIOServer } from "socket.io";
import type { Server as HTTPServer } from "http";
import { store } from "./store";
import { v4 as uuidv4 } from "uuid";

declare global {
  // eslint-disable-next-line no-var
  var __liberChatIO: SocketIOServer | undefined;
}

export function getIO(httpServer?: HTTPServer): SocketIOServer {
  if (!global.__liberChatIO) {
    if (!httpServer) throw new Error("httpServer required for first init");

    const io = new SocketIOServer(httpServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"],
      },
      path: "/api/socket",
      transports: ["websocket", "polling"],
    });

    io.on("connection", (socket) => {
      console.log("[socket] connected:", socket.id);

      // ── join-chat: user comes online ─────────────────────
      socket.on("join-chat", (userId: string) => {
        if (!userId) return;
        store.socketMap.set(userId, socket.id);
        socket.join(userId); // join a room named by userId
        console.log(`[socket] ${userId} joined (${socket.id})`);

        // Notify contacts that this user is online
        const contacts = store.contacts.filter((c) => c.ownerId === userId);
        for (const c of contacts) {
          const targetSocketId = store.socketMap.get(c.contactId);
          if (targetSocketId) {
            io.to(targetSocketId).emit("user-online", { userId });
          }
        }
      });

      // ── send-private-message ─────────────────────────────
      socket.on(
        "send-private-message",
        (data: {
          senderId: string;
          receiverId: string;
          content: string;
        }) => {
          const { senderId, receiverId, content } = data;
          if (!senderId || !receiverId || !content?.trim()) return;

          const msg: {
            id: string;
            senderId: string;
            receiverId: string;
            content: string;
            timestamp: number;
            status: "sent" | "delivered" | "read";
          } = {
            id: uuidv4(),
            senderId,
            receiverId,
            content: content.trim(),
            timestamp: Date.now(),
            status: "sent",
          };

          store.messages.push(msg);

          // Echo back to sender
          socket.emit("receive-message", msg);

          // Send to receiver if online
          const receiverSocketId = store.socketMap.get(receiverId);
          if (receiverSocketId) {
            msg.status = "delivered";
            io.to(receiverSocketId).emit("receive-message", msg);
            // Update status in store already done above
          }
        },
      );

      // ── mark-read ────────────────────────────────────────
      socket.on(
        "mark-read",
        (data: { viewerId: string; senderId: string }) => {
          const { viewerId, senderId } = data;
          // Update all messages from senderId to viewerId
          store.messages.forEach((m) => {
            if (m.senderId === senderId && m.receiverId === viewerId) {
              m.status = "read";
            }
          });
          // Notify sender
          const senderSocketId = store.socketMap.get(senderId);
          if (senderSocketId) {
            io.to(senderSocketId).emit("messages-read", {
              by: viewerId,
            });
          }
        },
      );

      // ── typing indicator ─────────────────────────────────
      socket.on(
        "typing",
        (data: { senderId: string; receiverId: string; isTyping: boolean }) => {
          const receiverSocketId = store.socketMap.get(data.receiverId);
          if (receiverSocketId) {
            io.to(receiverSocketId).emit("typing", {
              senderId: data.senderId,
              isTyping: data.isTyping,
            });
          }
        },
      );

      // ── disconnect ───────────────────────────────────────
      socket.on("disconnect", () => {
        // Remove from socketMap
        for (const [uid, sid] of store.socketMap.entries()) {
          if (sid === socket.id) {
            store.socketMap.delete(uid);
            // Notify contacts offline
            const contacts = store.contacts.filter((c) => c.ownerId === uid);
            for (const c of contacts) {
              const targetSocketId = store.socketMap.get(c.contactId);
              if (targetSocketId) {
                io.to(targetSocketId).emit("user-offline", { userId: uid });
              }
            }
            console.log(`[socket] ${uid} disconnected`);
            break;
          }
        }
      });
    });

    global.__liberChatIO = io;
  }

  return global.__liberChatIO;
}
