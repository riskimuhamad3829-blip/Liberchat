import { NextRequest, NextResponse } from "next/server";
import { store } from "@/lib/store";

// GET /api/messages?userId=xxx&contactId=yyy
export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get("userId");
  const contactId = req.nextUrl.searchParams.get("contactId");

  if (!userId || !contactId) {
    return NextResponse.json({ error: "userId and contactId required" }, { status: 400 });
  }

  const messages = store.messages
    .filter(
      (m) =>
        (m.senderId === userId && m.receiverId === contactId) ||
        (m.senderId === contactId && m.receiverId === userId),
    )
    .sort((a, b) => a.timestamp - b.timestamp);

  return NextResponse.json({ messages });
}
