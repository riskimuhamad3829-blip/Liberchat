import { NextRequest, NextResponse } from "next/server";
import { store } from "@/lib/store";

// GET /api/contacts?userId=xxx  → list contacts
export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get("userId");
  if (!userId) {
    return NextResponse.json({ error: "userId required" }, { status: 400 });
  }

  const contactIds = store.contacts
    .filter((c) => c.ownerId === userId)
    .map((c) => c.contactId);

  const contacts = contactIds
    .map((id) => store.users.get(id))
    .filter(Boolean)
    .map((u) => ({
      id: u!.id,
      phone: u!.phone,
      name: u!.name,
      avatar: u!.avatar,
      isOnline: store.socketMap.has(u!.id),
    }));

  return NextResponse.json({ contacts });
}

// POST /api/contacts  → add contact by phone
export async function POST(req: NextRequest) {
  try {
    const { ownerId, phone } = await req.json();

    if (!ownerId || !phone) {
      return NextResponse.json({ error: "ownerId dan phone wajib" }, { status: 400 });
    }

    const normalized = phone.replace(/\s+/g, "").trim();
    const targetId = store.phones.get(normalized);

    if (!targetId) {
      return NextResponse.json(
        { error: "Nomor HP tidak terdaftar di LiberChat" },
        { status: 404 },
      );
    }

    if (targetId === ownerId) {
      return NextResponse.json({ error: "Tidak bisa menambah diri sendiri" }, { status: 400 });
    }

    // Check if already a contact
    const already = store.contacts.some(
      (c) => c.ownerId === ownerId && c.contactId === targetId,
    );
    if (already) {
      return NextResponse.json({ error: "Kontak sudah ada" }, { status: 409 });
    }

    store.contacts.push({ ownerId, contactId: targetId });

    const target = store.users.get(targetId)!;
    return NextResponse.json({
      success: true,
      contact: {
        id: target.id,
        phone: target.phone,
        name: target.name,
        avatar: target.avatar,
        isOnline: store.socketMap.has(target.id),
      },
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
