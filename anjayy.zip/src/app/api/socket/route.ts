// Socket.io in Next.js App Router requires a custom server.
// This route just returns info; the actual socket server is
// initialized via the custom server in server.ts / server.js
import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    message: "Socket.io server is running on /api/socket (WebSocket upgrade)",
    status: "active",
  });
}
