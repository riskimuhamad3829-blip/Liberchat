import { NextRequest, NextResponse } from "next/server";
import { store } from "@/lib/store";

function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export async function POST(req: NextRequest) {
  try {
    const { phone } = await req.json();

    if (!phone || typeof phone !== "string") {
      return NextResponse.json({ error: "Phone number required" }, { status: 400 });
    }

    // Normalize phone
    const normalized = phone.replace(/\s+/g, "").trim();
    if (!normalized.startsWith("+62") || normalized.length < 10) {
      return NextResponse.json(
        { error: "Nomor HP harus diawali +62 dan minimal 10 digit" },
        { status: 400 },
      );
    }

    const otp = generateOTP();
    const expiresAt = Date.now() + 60_000; // 1 minute

    store.otps.set(normalized, {
      phone: normalized,
      otp,
      expiresAt,
      verified: false,
    });

    console.log(`[OTP] Phone: ${normalized} → OTP: ${otp}`); // visible in server logs

    // In production you'd send via SMS gateway.
    // Here we return it directly (simulation).
    return NextResponse.json({
      success: true,
      message: "OTP terkirim (simulasi)",
      // Only expose OTP in dev/demo mode
      otp: process.env.NODE_ENV !== "production" ? otp : undefined,
      expiresIn: 60,
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
