import { NextRequest, NextResponse } from "next/server";
import { store } from "@/lib/store";
import { v4 as uuidv4 } from "uuid";

export async function POST(req: NextRequest) {
  try {
    const { phone, otp, name } = await req.json();

    if (!phone || !otp) {
      return NextResponse.json({ error: "Phone dan OTP wajib diisi" }, { status: 400 });
    }

    const normalized = phone.replace(/\s+/g, "").trim();
    const record = store.otps.get(normalized);

    if (!record) {
      return NextResponse.json({ error: "OTP tidak ditemukan. Minta OTP baru." }, { status: 400 });
    }

    if (Date.now() > record.expiresAt) {
      store.otps.delete(normalized);
      return NextResponse.json({ error: "OTP sudah kadaluarsa. Minta OTP baru." }, { status: 400 });
    }

    if (record.otp !== otp.toString().trim()) {
      return NextResponse.json({ error: "OTP salah. Coba lagi." }, { status: 400 });
    }

    // OTP valid
    store.otps.delete(normalized);

    // Find or create user
    let userId = store.phones.get(normalized);
    let isNew = false;

    if (!userId) {
      isNew = true;
      userId = uuidv4();
      const displayName = name?.trim() || `User ${normalized.slice(-4)}`;
      const user = {
        id: userId,
        phone: normalized,
        name: displayName,
        avatar: "/default-avatar.png",
        createdAt: Date.now(),
      };
      store.users.set(userId, user);
      store.phones.set(normalized, userId);
    }

    const user = store.users.get(userId)!;

    return NextResponse.json({
      success: true,
      isNew,
      user: {
        id: user.id,
        phone: user.phone,
        name: user.name,
        avatar: user.avatar,
      },
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
