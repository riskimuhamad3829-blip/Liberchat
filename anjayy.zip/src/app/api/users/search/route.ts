import { NextRequest, NextResponse } from "next/server";
import { store } from "@/lib/store";

// GET /api/users/search?phone=+62xxx
export async function GET(req: NextRequest) {
  const phone = req.nextUrl.searchParams.get("phone");
  if (!phone) {
    return NextResponse.json({ error: "phone required" }, { status: 400 });
  }

  const normalized = phone.replace(/\s+/g, "").trim();
  const userId = store.phones.get(normalized);

  if (!userId) {
    return NextResponse.json({ found: false, user: null });
  }

  const user = store.users.get(userId)!;
  return NextResponse.json({
    found: true,
    user: {
      id: user.id,
      phone: user.phone,
      name: user.name,
      avatar: user.avatar,
    },
  });
}
