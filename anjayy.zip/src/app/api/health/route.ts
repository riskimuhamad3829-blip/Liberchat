import { NextResponse } from "next/server";
import { store } from "@/lib/store";

export async function GET() {
  return NextResponse.json({
    status: "ok",
    app: "LiberChat",
    users: store.users.size,
    messages: store.messages.length,
    connections: store.socketMap.size,
    timestamp: new Date().toISOString(),
  });
}
