"use client";

import { useState, useCallback, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useSocket } from "@/hooks/useSocket";
import LoginScreen from "@/components/LoginScreen";
import Sidebar from "@/components/Sidebar";
import ChatWindow from "@/components/ChatWindow";
import WelcomeScreen from "@/components/WelcomeScreen";
import type { Contact, Message } from "@/types";

export default function Home() {
  const { user, loading, login, logout } = useAuth();
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
  const [latestMessages, setLatestMessages] = useState<Record<string, Message>>({});
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [showMobileChat, setShowMobileChat] = useState(false);

  // Initialize latest messages from loaded contacts
  useEffect(() => {
    if (!user) return;
    // Fetch initial latest messages for sidebar
    fetch(`/api/contacts?userId=${user.id}`)
      .then((r) => r.json())
      .then(async (data) => {
        if (!data.contacts) return;
        const msgs: Record<string, Message> = {};
        const unreads: Record<string, number> = {};
        await Promise.all(
          data.contacts.map(async (c: Contact) => {
            const res = await fetch(`/api/messages?userId=${user.id}&contactId=${c.id}`);
            const d = await res.json();
            if (d.messages?.length > 0) {
              const sorted = [...d.messages].sort((a: Message, b: Message) => b.timestamp - a.timestamp);
              msgs[c.id] = sorted[0];
              // Count unread
              unreads[c.id] = d.messages.filter(
                (m: Message) => m.senderId === c.id && m.status !== "read",
              ).length;
            }
          }),
        );
        setLatestMessages(msgs);
        setUnreadCounts(unreads);
      })
      .catch(() => {});
  }, [user]);

  // Socket handlers
  const handleMessage = useCallback(
    (msg: Message) => {
      // Determine which contact this belongs to
      const otherId =
        msg.senderId === user?.id ? msg.receiverId : msg.senderId;

      // Update latest messages
      setLatestMessages((prev) => {
        const current = prev[otherId];
        if (!current || msg.timestamp > current.timestamp) {
          return { ...prev, [otherId]: msg };
        }
        return prev;
      });

      // Update unread counts (only if not currently viewing)
      if (msg.senderId !== user?.id) {
        const isViewingThis = selectedContact?.id === msg.senderId;
        if (!isViewingThis) {
          setUnreadCounts((prev) => ({
            ...prev,
            [msg.senderId]: (prev[msg.senderId] ?? 0) + 1,
          }));
        }
      }

      // Forward to chat window if open
      const handler = (window as unknown as Record<string, unknown>)[
        `__chatHandler_${otherId}`
      ];
      if (typeof handler === "function") {
        (handler as (msg: Message) => void)(msg);
      }
    },
    [user?.id, selectedContact?.id],
  );

  const handleUserOnline = useCallback((uid: string) => {
    setOnlineUsers((prev) => new Set([...prev, uid]));
  }, []);

  const handleUserOffline = useCallback((uid: string) => {
    setOnlineUsers((prev) => {
      const next = new Set(prev);
      next.delete(uid);
      return next;
    });
  }, []);

  const handleTyping = useCallback((senderId: string, isTyping: boolean) => {
    setTypingUsers((prev) => {
      const next = new Set(prev);
      if (isTyping) next.add(senderId);
      else next.delete(senderId);
      return next;
    });
  }, []);

  const handleMessagesRead = useCallback((by: string) => {
    // Update message statuses in sidebar
    setLatestMessages((prev) => {
      const msg = prev[by];
      if (msg && msg.status !== "read") {
        return { ...prev, [by]: { ...msg, status: "read" } };
      }
      return prev;
    });
  }, []);

  const { connected, sendMessage, sendTyping, markRead } = useSocket({
    userId: user?.id ?? null,
    onMessage: handleMessage,
    onUserOnline: handleUserOnline,
    onUserOffline: handleUserOffline,
    onTyping: handleTyping,
    onMessagesRead: handleMessagesRead,
  });

  const handleSelectContact = (contact: Contact) => {
    setSelectedContact(contact);
    setShowMobileChat(true);
    // Clear unread
    setUnreadCounts((prev) => ({ ...prev, [contact.id]: 0 }));
  };

  const handleNewMessage = useCallback((msg: Message) => {
    const otherId = msg.senderId === user?.id ? msg.receiverId : msg.senderId;
    setLatestMessages((prev) => {
      const current = prev[otherId];
      if (!current || msg.timestamp > current.timestamp) {
        return { ...prev, [otherId]: msg };
      }
      return prev;
    });
  }, [user?.id]);

  if (loading) {
    return (
      <div
        className="flex items-center justify-center h-screen"
        style={{ background: "#111b21" }}
      >
        <div
          className="w-12 h-12 rounded-full border-3 border-t-transparent animate-spin"
          style={{ borderColor: "#00a884", borderTopColor: "transparent", borderWidth: 3 }}
        />
      </div>
    );
  }

  if (!user) {
    return <LoginScreen onLogin={login} />;
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "#111b21" }}>
      {/* Connection indicator */}
      {!connected && (
        <div
          className="fixed top-0 left-0 right-0 z-50 text-center py-1 text-xs font-medium"
          style={{ background: "#f39c12", color: "#000" }}
        >
          ⚠️ Menghubungkan ke server...
        </div>
      )}

      {/* ── DESKTOP: Two-column layout ── */}
      {/* Sidebar */}
      <div
        className={`flex-shrink-0 ${showMobileChat ? "hidden md:flex" : "flex"} flex-col`}
        style={{ width: "100%", maxWidth: 400 }}
      >
        <Sidebar
          currentUser={user}
          selectedContactId={selectedContact?.id ?? null}
          onSelectContact={handleSelectContact}
          onlineUsers={onlineUsers}
          latestMessages={latestMessages}
          unreadCounts={unreadCounts}
          onLogout={logout}
        />
      </div>

      {/* Chat Area */}
      <div
        className={`flex-1 ${showMobileChat ? "flex" : "hidden md:flex"} flex-col min-w-0`}
      >
        {selectedContact ? (
          <ChatWindow
            key={selectedContact.id}
            currentUser={user}
            contact={{
              ...selectedContact,
              isOnline: onlineUsers.has(selectedContact.id),
            }}
            onBack={() => setShowMobileChat(false)}
            onNewMessage={handleNewMessage}
            sendMessage={sendMessage}
            sendTyping={sendTyping}
            markRead={markRead}
            incomingTyping={typingUsers.has(selectedContact.id)}
            connected={connected}
          />
        ) : (
          <WelcomeScreen />
        )}
      </div>
    </div>
  );
}
