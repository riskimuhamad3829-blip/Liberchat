import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LiberChat",
  description: "LiberChat – WhatsApp Clone. Chat bebas, real-time, private.",
  icons: {
    icon: "/favicon.ico",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body style={{ height: "100dvh", overflow: "hidden" }}>
        {children}
      </body>
    </html>
  );
}
