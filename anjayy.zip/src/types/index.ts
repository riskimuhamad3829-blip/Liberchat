export interface User {
  id: string;
  phone: string;
  name: string;
  avatar: string;
}

export interface Contact extends User {
  isOnline: boolean;
  lastMessage?: Message;
  unreadCount?: number;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
  status: "sent" | "delivered" | "read";
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}
