"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Send, Phone, Video, MoreVertical, ArrowLeft, Smile } from "lucide-react";
import type { User, Contact, Message } from "@/types";
import { format } from "date-fns";
import { id as idLocale } from "date-fns/locale";

interface Props {
  currentUser: User;
  contact: Contact;
  onBack?: () => void;
  onNewMessage: (msg: Message) => void;
  sendMessage: (senderId: string, receiverId: string, content: string) => void;
  sendTyping: (senderId: string, receiverId: string, isTyping: boolean) => void;
  markRead: (viewerId: string, senderId: string) => void;
  incomingTyping: boolean;
  connected: boolean;
}

const EMOJIS = ["😀","😂","😍","🥰","😊","😎","🤔","😅","🙈","🔥","❤️","👍","👏","🎉","✅","💯","🙏","😭","😤","🤣"];

function StatusTick({ status }: { status: Message["status"] }) {
  if (status === "read")
    return <span style={{ color: "#53bdeb", fontSize: 11 }}>✓✓</span>;
  if (status === "delivered")
    return <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>✓✓</span>;
  return <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>✓</span>;
}

function groupMessagesByDate(messages: Message[]) {
  const groups: { date: string; messages: Message[] }[] = [];
  let currentDate = "";

  for (const msg of messages) {
    const d = format(new Date(msg.timestamp), "d MMMM yyyy", { locale: idLocale });
    if (d !== currentDate) {
      currentDate = d;
      groups.push({ date: d, messages: [msg] });
    } else {
      groups[groups.length - 1].messages.push(msg);
    }
  }
  return groups;
}

export default function ChatWindow({
  currentUser,
  contact,
  onBack,
  onNewMessage,
  sendMessage,
  sendTyping,
  markRead,
  incomingTyping,
  connected,
}: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch message history
  const fetchMessages = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/messages?userId=${currentUser.id}&contactId=${contact.id}`,
      );
      const data = await res.json();
      if (data.messages) {
        setMessages(data.messages);
        // Mark as read
        markRead(currentUser.id, contact.id);
      }
    } catch {
      // ignore
    }
    setLoading(false);
  }, [currentUser.id, contact.id, markRead]);

  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  // Scroll to bottom when messages change
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, incomingTyping]);

  // Listen for new messages from socket (passed from parent)
  const addMessage = useCallback(
    (msg: Message) => {
      const isRelevant =
        (msg.senderId === currentUser.id && msg.receiverId === contact.id) ||
        (msg.senderId === contact.id && msg.receiverId === currentUser.id);
      if (!isRelevant) return;

      setMessages((prev) => {
        // Avoid duplicates
        if (prev.find((m) => m.id === msg.id)) {
          return prev.map((m) => (m.id === msg.id ? msg : m));
        }
        return [...prev, msg];
      });

      if (msg.senderId === contact.id) {
        markRead(currentUser.id, contact.id);
      }
      onNewMessage(msg);
    },
    [currentUser.id, contact.id, markRead, onNewMessage],
  );

  // Expose addMessage via ref so parent can call it
  useEffect(() => {
    // Store handler in window for parent access
    (window as unknown as Record<string, unknown>)[`__chatHandler_${contact.id}`] = addMessage;
    return () => {
      delete (window as unknown as Record<string, unknown>)[`__chatHandler_${contact.id}`];
    };
  }, [addMessage, contact.id]);

  const handleSend = () => {
    const content = input.trim();
    if (!content || !connected) return;
    sendMessage(currentUser.id, contact.id, content);
    setInput("");
    setShowEmoji(false);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    sendTyping(currentUser.id, contact.id, false);
  };

  const handleInputChange = (val: string) => {
    setInput(val);
    sendTyping(currentUser.id, contact.id, val.length > 0);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      sendTyping(currentUser.id, contact.id, false);
    }, 2000);
  };

  const groups = groupMessagesByDate(messages);

  return (
    <div className="flex flex-col h-full" style={{ background: "#0b141a" }}>
      {/* ── Header ── */}
      <div
        className="flex items-center gap-3 px-4 py-2 flex-shrink-0 z-10"
        style={{ background: "#202c33", minHeight: 60, boxShadow: "0 1px 3px rgba(0,0,0,0.3)" }}
      >
        {onBack && (
          <button
            onClick={onBack}
            className="p-1 mr-1 rounded-full hover:bg-white/10 transition-colors"
            style={{ color: "#aebac1" }}
          >
            <ArrowLeft size={20} />
          </button>
        )}

        {/* Avatar */}
        <div className="relative flex-shrink-0">
          <div
            className="rounded-full flex items-center justify-center font-bold"
            style={{ width: 40, height: 40, background: "#2a3942", color: "#00a884", fontSize: 16 }}
          >
            {contact.name.charAt(0).toUpperCase()}
          </div>
          {contact.isOnline && (
            <div
              className="absolute bottom-0 right-0 rounded-full"
              style={{ width: 11, height: 11, background: "#25d366", border: "2px solid #202c33" }}
            />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm leading-tight truncate" style={{ color: "#e9edef" }}>
            {contact.name}
          </p>
          <p className="text-xs" style={{ color: "#8696a0" }}>
            {incomingTyping
              ? "sedang mengetik..."
              : contact.isOnline
              ? "online"
              : contact.phone}
          </p>
        </div>

        <div className="flex items-center gap-1">
          <button
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
            style={{ color: "#aebac1" }}
            title="Telepon"
          >
            <Phone size={18} />
          </button>
          <button
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
            style={{ color: "#aebac1" }}
            title="Video call"
          >
            <Video size={18} />
          </button>
          <button
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
            style={{ color: "#aebac1" }}
          >
            <MoreVertical size={18} />
          </button>
        </div>
      </div>

      {/* ── Chat Background Pattern ── */}
      <div
        className="flex-1 overflow-y-auto px-4 py-2 relative"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.02'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      >
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <div
              className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin"
              style={{ borderColor: "#00a884", borderTopColor: "transparent" }}
            />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-3">
            <div
              className="rounded-2xl px-5 py-3 text-sm text-center"
              style={{ background: "rgba(0,0,0,0.3)", color: "#8696a0" }}
            >
              🔒 Pesan dienkripsi end-to-end. Mulai obrolan dengan {contact.name}!
            </div>
          </div>
        ) : (
          <>
            {groups.map((group) => (
              <div key={group.date}>
                {/* Date separator */}
                <div className="flex justify-center my-3">
                  <span
                    className="text-xs px-3 py-1 rounded-full"
                    style={{ background: "#182229", color: "#8696a0" }}
                  >
                    {group.date}
                  </span>
                </div>

                {group.messages.map((msg) => {
                  const isMine = msg.senderId === currentUser.id;
                  return (
                    <div
                      key={msg.id}
                      className={`flex mb-1 fade-in ${isMine ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className="relative max-w-xs md:max-w-sm lg:max-w-md px-3 py-2 rounded-xl shadow-sm"
                        style={{
                          background: isMine ? "#005c4b" : "#202c33",
                          borderRadius: isMine
                            ? "12px 12px 2px 12px"
                            : "12px 12px 12px 2px",
                          maxWidth: "72%",
                        }}
                      >
                        <p
                          className="text-sm leading-relaxed break-words"
                          style={{ color: "#e9edef" }}
                        >
                          {msg.content}
                        </p>
                        <div
                          className="flex items-center justify-end gap-1 mt-1"
                          style={{ minWidth: 60 }}
                        >
                          <span
                            className="text-xs"
                            style={{ color: "rgba(255,255,255,0.5)", fontSize: 10 }}
                          >
                            {format(new Date(msg.timestamp), "HH:mm")}
                          </span>
                          {isMine && <StatusTick status={msg.status} />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}

            {/* Typing indicator */}
            {incomingTyping && (
              <div className="flex justify-start mb-2 fade-in">
                <div
                  className="px-4 py-3 rounded-xl flex items-center gap-1"
                  style={{ background: "#202c33", borderRadius: "12px 12px 12px 2px" }}
                >
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="rounded-full"
                      style={{
                        width: 7,
                        height: 7,
                        background: "#8696a0",
                        animation: `bounce 1.2s infinite ${i * 0.15}s`,
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
        <div ref={bottomRef} />
      </div>

      {/* ── Emoji Picker ── */}
      {showEmoji && (
        <div
          className="px-4 py-3 flex flex-wrap gap-2 flex-shrink-0"
          style={{ background: "#202c33", borderTop: "1px solid #2a3942" }}
        >
          {EMOJIS.map((em) => (
            <button
              key={em}
              onClick={() => setInput((prev) => prev + em)}
              className="text-xl hover:scale-125 transition-transform"
            >
              {em}
            </button>
          ))}
        </div>
      )}

      {/* ── Input Bar ── */}
      <div
        className="px-3 py-3 flex items-end gap-2 flex-shrink-0"
        style={{ background: "#202c33" }}
      >
        <button
          onClick={() => setShowEmoji(!showEmoji)}
          className="p-2 rounded-full hover:bg-white/10 transition-colors flex-shrink-0"
          style={{ color: "#aebac1" }}
        >
          <Smile size={22} />
        </button>

        <div
          className="flex-1 rounded-2xl px-4 py-2 flex items-end"
          style={{ background: "#2a3942", minHeight: 44, maxHeight: 120 }}
        >
          <textarea
            value={input}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ketik pesan..."
            rows={1}
            style={{
              color: "#e9edef",
              resize: "none",
              overflow: "hidden",
              lineHeight: "1.4",
              width: "100%",
            }}
            className="bg-transparent text-sm outline-none flex-1 self-center"
            onInput={(e) => {
              const el = e.currentTarget;
              el.style.height = "auto";
              el.style.height = Math.min(el.scrollHeight, 96) + "px";
            }}
          />
        </div>

        <button
          onClick={handleSend}
          disabled={!input.trim() || !connected}
          className="p-3 rounded-full flex-shrink-0 transition-all duration-200 disabled:opacity-40"
          style={{ background: "#00a884", color: "white" }}
        >
          <Send size={18} />
        </button>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
