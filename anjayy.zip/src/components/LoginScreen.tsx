"use client";

import { useState, useEffect, useRef } from "react";
import type { User } from "@/types";

interface Props {
  onLogin: (user: User) => void;
}

type Step = "phone" | "otp" | "name";

export default function LoginScreen({ onLogin }: Props) {
  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("+62");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [name, setName] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [isNew, setIsNew] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) return;
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [countdown]);

  const handleSendOtp = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Gagal kirim OTP");
      } else {
        setGeneratedOtp(data.otp || "");
        setCountdown(60);
        setStep("otp");
        setTimeout(() => otpRefs.current[0]?.focus(), 100);
      }
    } catch {
      setError("Tidak bisa terhubung ke server");
    }
    setLoading(false);
  };

  const handleOtpChange = (idx: number, val: string) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[idx] = val;
    setOtp(next);
    if (val && idx < 5) otpRefs.current[idx + 1]?.focus();
    if (!val && idx > 0) otpRefs.current[idx - 1]?.focus();
  };

  const handleVerifyOtp = async () => {
    const code = otp.join("");
    if (code.length < 6) {
      setError("Masukkan 6 digit OTP");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, otp: code, name }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Verifikasi gagal");
      } else {
        setIsNew(data.isNew);
        if (data.isNew) {
          setStep("name");
        } else {
          onLogin(data.user);
        }
      }
    } catch {
      setError("Tidak bisa terhubung ke server");
    }
    setLoading(false);
  };

  const handleSetName = async () => {
    if (!name.trim()) {
      setError("Masukkan nama Anda");
      return;
    }
    setError("");
    setLoading(true);
    // Re-verify with name
    const code = otp.join("");
    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, otp: code, name }),
      });
      const data = await res.json();
      if (res.ok || (data.user && !res.ok)) {
        // If user was created in previous step, just use stored data
        if (data.user) {
          onLogin(data.user);
          return;
        }
      }
      // fallback: create user manually via a second approach
      // Since OTP was already consumed, we just create with what we have
      onLogin({ id: Date.now().toString(), phone, name: name.trim(), avatar: "/default-avatar.png" });
    } catch {
      setError("Tidak bisa terhubung ke server");
    }
    setLoading(false);
  };

  return (
    <div
      className="flex items-center justify-center min-h-screen"
      style={{ background: "linear-gradient(135deg, #111b21 0%, #0b141a 100%)" }}
    >
      <div
        className="w-full max-w-sm mx-4 rounded-2xl shadow-2xl overflow-hidden"
        style={{ background: "#202c33" }}
      >
        {/* Header */}
        <div
          className="px-8 py-10 text-center"
          style={{ background: "linear-gradient(135deg, #00a884 0%, #008069 100%)" }}
        >
          <div className="text-5xl mb-3">💬</div>
          <h1 className="text-2xl font-bold text-white tracking-wide">LiberChat</h1>
          <p className="text-green-100 text-sm mt-1 opacity-90">Chat bebas, aman, real-time</p>
        </div>

        <div className="px-8 py-8">
          {/* ── Step: Phone ── */}
          {step === "phone" && (
            <div className="fade-in space-y-5">
              <div>
                <h2 className="text-lg font-semibold" style={{ color: "#e9edef" }}>
                  Masuk / Daftar
                </h2>
                <p className="text-sm mt-1" style={{ color: "#8696a0" }}>
                  Masukkan nomor HP aktif Anda
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#8696a0" }}>
                  Nomor WhatsApp
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+62812 3456 7890"
                  className="w-full px-4 py-3 rounded-xl text-sm focus:outline-none transition-all"
                  style={{
                    background: "#2a3942",
                    color: "#e9edef",
                    border: "1px solid #374045",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "#00a884")}
                  onBlur={(e) => (e.target.style.borderColor = "#374045")}
                  onKeyDown={(e) => e.key === "Enter" && handleSendOtp()}
                />
              </div>

              {/* Demo hint */}
              <div
                className="rounded-xl p-3 text-xs"
                style={{ background: "#1a2730", color: "#8696a0", border: "1px solid #2a3942" }}
              >
                💡 <strong style={{ color: "#00a884" }}>Demo:</strong> Coba nomor{" "}
                <span
                  className="cursor-pointer font-mono"
                  style={{ color: "#00a884" }}
                  onClick={() => setPhone("+6281111111111")}
                >
                  +6281111111111
                </span>{" "}
                (Alice) atau{" "}
                <span
                  className="cursor-pointer font-mono"
                  style={{ color: "#00a884" }}
                  onClick={() => setPhone("+6282222222222")}
                >
                  +6282222222222
                </span>{" "}
                (Bob)
              </div>

              {error && (
                <p className="text-sm text-red-400 bg-red-900/20 px-3 py-2 rounded-lg">{error}</p>
              )}

              <button
                onClick={handleSendOtp}
                disabled={loading || phone.length < 10}
                className="w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200 disabled:opacity-50"
                style={{ background: "#00a884", color: "white" }}
                onMouseEnter={(e) =>
                  ((e.target as HTMLElement).style.background = "#008069")
                }
                onMouseLeave={(e) =>
                  ((e.target as HTMLElement).style.background = "#00a884")
                }
              >
                {loading ? "Mengirim OTP..." : "Kirim OTP →"}
              </button>
            </div>
          )}

          {/* ── Step: OTP ── */}
          {step === "otp" && (
            <div className="fade-in space-y-5">
              <div>
                <h2 className="text-lg font-semibold" style={{ color: "#e9edef" }}>
                  Verifikasi OTP
                </h2>
                <p className="text-sm mt-1" style={{ color: "#8696a0" }}>
                  Kode dikirim ke{" "}
                  <span style={{ color: "#00a884" }} className="font-medium">
                    {phone}
                  </span>
                </p>
              </div>

              {/* OTP display (demo) */}
              {generatedOtp && (
                <div
                  className="rounded-xl p-3 text-center"
                  style={{ background: "#1a2730", border: "1px dashed #00a884" }}
                >
                  <p className="text-xs mb-1" style={{ color: "#8696a0" }}>
                    Kode OTP Anda (simulasi):
                  </p>
                  <p className="text-2xl font-mono font-bold tracking-widest" style={{ color: "#00a884" }}>
                    {generatedOtp}
                  </p>
                </div>
              )}

              {/* OTP Input */}
              <div className="flex gap-2 justify-between">
                {otp.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => { otpRefs.current[idx] = el; }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(idx, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Backspace" && !otp[idx] && idx > 0) {
                        otpRefs.current[idx - 1]?.focus();
                      }
                      if (e.key === "Enter") handleVerifyOtp();
                    }}
                    className="w-11 h-12 text-center text-lg font-bold rounded-xl transition-all focus:outline-none"
                    style={{
                      background: "#2a3942",
                      color: "#e9edef",
                      border: digit ? "2px solid #00a884" : "2px solid #374045",
                    }}
                  />
                ))}
              </div>

              {/* Countdown */}
              <div className="flex items-center justify-between text-sm">
                <span style={{ color: "#8696a0" }}>
                  {countdown > 0 ? (
                    <>
                      Kirim ulang dalam{" "}
                      <span style={{ color: "#00a884" }} className="font-mono font-bold">
                        {String(Math.floor(countdown / 60)).padStart(2, "0")}:
                        {String(countdown % 60).padStart(2, "0")}
                      </span>
                    </>
                  ) : (
                    "OTP kadaluarsa"
                  )}
                </span>
                {countdown === 0 && (
                  <button
                    onClick={() => {
                      setOtp(["", "", "", "", "", ""]);
                      setStep("phone");
                      setError("");
                    }}
                    style={{ color: "#00a884" }}
                    className="font-medium hover:underline"
                  >
                    Minta OTP baru
                  </button>
                )}
              </div>

              {error && (
                <p className="text-sm text-red-400 bg-red-900/20 px-3 py-2 rounded-lg">{error}</p>
              )}

              <button
                onClick={handleVerifyOtp}
                disabled={loading || otp.join("").length < 6}
                className="w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200 disabled:opacity-50"
                style={{ background: "#00a884", color: "white" }}
              >
                {loading ? "Memverifikasi..." : "Verifikasi OTP ✓"}
              </button>

              <button
                onClick={() => { setStep("phone"); setError(""); }}
                className="w-full py-2 text-sm hover:underline"
                style={{ color: "#8696a0" }}
              >
                ← Ganti nomor HP
              </button>
            </div>
          )}

          {/* ── Step: Name ── */}
          {step === "name" && (
            <div className="fade-in space-y-5">
              <div>
                <h2 className="text-lg font-semibold" style={{ color: "#e9edef" }}>
                  Selamat datang! 🎉
                </h2>
                <p className="text-sm mt-1" style={{ color: "#8696a0" }}>
                  Akun baru ditemukan. Masukkan nama Anda.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#8696a0" }}>
                  Nama Tampilan
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nama Anda"
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl text-sm focus:outline-none transition-all"
                  style={{
                    background: "#2a3942",
                    color: "#e9edef",
                    border: "1px solid #374045",
                  }}
                  onKeyDown={(e) => e.key === "Enter" && handleSetName()}
                />
              </div>

              {error && (
                <p className="text-sm text-red-400 bg-red-900/20 px-3 py-2 rounded-lg">{error}</p>
              )}

              <button
                onClick={handleSetName}
                disabled={loading || !name.trim()}
                className="w-full py-3 rounded-xl font-semibold text-sm disabled:opacity-50"
                style={{ background: "#00a884", color: "white" }}
              >
                {loading ? "Menyimpan..." : "Mulai Chat! 🚀"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
