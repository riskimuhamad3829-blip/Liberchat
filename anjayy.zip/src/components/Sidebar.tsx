"use client";

import { useState, useEffect, useCallback } from "react";
import { Search, Plus, MoreVertical, MessageCircle, X, Check } from "lucide-react";
import type { User, Contact, Message } from "@/types";
import { format, isToday, isYesterday } from "date-fns";
import { id as idLocale } from "date-fns/locale";

interface Props {
  currentUser: User;
  selectedContactId: string | null;
  onSelectContact: (contact: Contact) => void;
  onlineUsers: Set<string>;
  latestMessages: Record<string, Message>;
  unreadCounts: Record<string, number>;
  onLogout: () => void;
}

function formatTime(ts: number): string {
  const date = new Date(ts);
  if (isToday(date)) return format(date, "HH:mm");
  if (isYesterday(date)) return "Kemarin";
  return format(date, "dd/MM/yy", { locale: idLocale });
}

function Avatar({ src, name, size = 40, isOnline = false }: { src: string; name: string; size?: number; isOnline?: boolean }) {
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <div
        className="rounded-full overflow-hidden flex items-center justify-center font-bold"
        style={{
          width: size,
          height: size,
          background: "#2a3942",
          fontSize: size * 0.35,
          color: "#00a884",
        }}
      >
        {src ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={src} alt={name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          name.charAt(0).toUpperCase()
        )}
      </div>
      {isOnline && (
        <div
          className="absolute bottom-0 right-0 rounded-full"
          style={{ width: size * 0.27, height: size * 0.27, background: "#25d366", border: "2px solid #111b21" }}
        />
      )}
    </div>
  );
}

export default function Sidebar({
  currentUser,
  selectedContactId,
  onSelectContact,
  onlineUsers,
  latestMessages,
  unreadCounts,
  onLogout,
}: Props) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [addPhone, setAddPhone] = useState("+62");
  const [addError, setAddError] = useState("");
  const [addLoading, setAddLoading] = useState(false);
  const [addSuccess, setAddSuccess] = useState("");
  const [showMenu, setShowMenu] = useState(false);

  const fetchContacts = useCallback(async () => {
    try {
      const res = await fetch(`/api/contacts?userId=${currentUser.id}`);
      const data = await res.json();
      if (data.contacts) {
        setContacts(
          data.contacts.map((c: Contact) => ({
            ...c,
            isOnline: onlineUsers.has(c.id),
          })),
        );
      }
    } catch {
      // ignore
    }
  }, [currentUser.id, onlineUsers]);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  // Update online status from prop
  const contactsWithOnline = contacts.map((c) => ({
    ...c,
    isOnline: onlineUsers.has(c.id),
  }));

  const filtered = contactsWithOnline.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search),
  );

  // Sort by last message timestamp
  const sorted = [...filtered].sort((a, b) => {
    const aTs = latestMessages[a.id]?.timestamp ?? 0;
    const bTs = latestMessages[b.id]?.timestamp ?? 0;
    return bTs - aTs;
  });

  const handleAddContact = async () => {
    setAddError("");
    setAddSuccess("");
    setAddLoading(true);
    try {
      const res = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ownerId: currentUser.id, phone: addPhone }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAddError(data.error || "Gagal menambah kontak");
      } else {
        setAddSuccess(`${data.contact.name} berhasil ditambahkan!`);
        setAddPhone("+62");
        fetchContacts();
        setTimeout(() => {
          setShowAddModal(false);
          setAddSuccess("");
        }, 1500);
      }
    } catch {
      setAddError("Tidak bisa terhubung ke server");
    }
    setAddLoading(false);
  };

  const getStatusIcon = (msg: Message, currentUserId: string) => {
    if (msg.senderId !== currentUserId) return null;
    if (msg.status === "read")
      return <span style={{ color: "#53bdeb" }} className="text-xs">✓✓</span>;
    if (msg.status === "delivered")
      return <span style={{ color: "#8696a0" }} className="text-xs">✓✓</span>;
    return <span style={{ color: "#8696a0" }} className="text-xs">✓</span>;
  };

  return (
    <div
      className="flex flex-col h-full"
      style={{ background: "#111b21", borderRight: "1px solid #222d34" }}
    >
      {/* ── Header ── */}
      <div
        className="flex items-center justify-between px-4 py-3 flex-shrink-0"
        style={{ background: "#202c33", minHeight: 60 }}
      >
        <div className="flex items-center gap-3">
          <Avatar src={currentUser.avatar} name={currentUser.name} size={40} />
          <div>
            <p className="font-semibold text-sm leading-tight" style={{ color: "#e9edef" }}>
              {currentUser.name}
            </p>
            <p className="text-xs" style={{ color: "#8696a0" }}>
              {currentUser.phone}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowAddModal(true)}
            className="p-2 rounded-full transition-colors hover:bg-white/10"
            title="Tambah Kontak"
            style={{ color: "#aebac1" }}
          >
            <Plus size={20} />
          </button>
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 rounded-full transition-colors hover:bg-white/10"
              style={{ color: "#aebac1" }}
            >
              <MoreVertical size={20} />
            </button>
            {showMenu && (
              <div
                className="absolute right-0 top-10 rounded-xl shadow-xl z-50 overflow-hidden"
                style={{ background: "#233138", minWidth: 160, border: "1px solid #2a3942" }}
              >
                <button
                  onClick={() => { setShowMenu(false); onLogout(); }}
                  className="w-full text-left px-4 py-3 text-sm transition-colors hover:bg-white/10"
                  style={{ color: "#e9edef" }}
                >
                  Keluar
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Search ── */}
      <div className="px-3 py-2 flex-shrink-0" style={{ background: "#111b21" }}>
        <div
          className="flex items-center gap-3 px-4 py-2 rounded-full"
          style={{ background: "#202c33" }}
        >
          <Search size={16} style={{ color: "#8696a0" }} />
          <input
            type="text"
            placeholder="Cari atau mulai chat baru"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: "#e9edef" }}
          />
          {search && (
            <button onClick={() => setSearch("")}>
              <X size={16} style={{ color: "#8696a0" }} />
            </button>
          )}
        </div>
      </div>

      {/* ── Contact List ── */}
      <div className="flex-1 overflow-y-auto">
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 px-6 text-center">
            <MessageCircle size={48} style={{ color: "#2a3942" }} />
            <p style={{ color: "#8696a0" }} className="text-sm">
              {search ? "Kontak tidak ditemukan" : "Belum ada kontak. Klik + untuk menambah."}
            </p>
          </div>
        ) : (
          sorted.map((contact) => {
            const lastMsg = latestMessages[contact.id];
            const unread = unreadCounts[contact.id] ?? 0;
            const isSelected = selectedContactId === contact.id;

            return (
              <div
                key={contact.id}
                onClick={() => onSelectContact(contact)}
                className="flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors relative"
                style={{
                  background: isSelected ? "#2a3942" : "transparent",
                  borderBottom: "1px solid #222d34",
                }}
                onMouseEnter={(e) => {
                  if (!isSelected)
                    (e.currentTarget as HTMLElement).style.background = "#1a2730";
                }}
                onMouseLeave={(e) => {
                  if (!isSelected)
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                }}
              >
                <Avatar
                  src={contact.avatar}
                  name={contact.name}
                  size={50}
                  isOnline={contact.isOnline}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p
                      className="font-medium text-sm truncate"
                      style={{ color: "#e9edef", maxWidth: "60%" }}
                    >
                      {contact.name}
                    </p>
                    {lastMsg && (
                      <span
                        className="text-xs flex-shrink-0 ml-1"
                        style={{ color: unread > 0 ? "#00a884" : "#8696a0" }}
                      >
                        {formatTime(lastMsg.timestamp)}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-0.5">
                    <p
                      className="text-xs truncate flex items-center gap-1"
                      style={{ color: "#8696a0", maxWidth: "75%" }}
                    >
                      {lastMsg ? (
                        <>
                          {getStatusIcon(lastMsg, currentUser.id)}
                          <span>{lastMsg.content}</span>
                        </>
                      ) : (
                        <span>Belum ada pesan</span>
                      )}
                    </p>
                    {unread > 0 && (
                      <span
                        className="text-xs font-bold rounded-full flex items-center justify-center flex-shrink-0"
                        style={{
                          background: "#00a884",
                          color: "white",
                          minWidth: 20,
                          height: 20,
                          padding: "0 6px",
                        }}
                      >
                        {unread}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ── Add Contact Modal ── */}
      {showAddModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: "rgba(0,0,0,0.7)" }}
          onClick={(e) => e.target === e.currentTarget && setShowAddModal(false)}
        >
          <div
            className="w-full max-w-sm mx-4 rounded-2xl overflow-hidden shadow-2xl"
            style={{ background: "#202c33" }}
          >
            <div className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: "1px solid #2a3942" }}>
              <h3 className="font-semibold" style={{ color: "#e9edef" }}>
                Tambah Kontak
              </h3>
              <button
                onClick={() => { setShowAddModal(false); setAddError(""); setAddSuccess(""); setAddPhone("+62"); }}
                className="p-1 rounded-full hover:bg-white/10 transition-colors"
                style={{ color: "#aebac1" }}
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: "#8696a0" }}>
                  Nomor HP (+62...)
                </label>
                <input
                  type="tel"
                  value={addPhone}
                  onChange={(e) => setAddPhone(e.target.value)}
                  placeholder="+6281234567890"
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                  style={{ background: "#2a3942", color: "#e9edef", border: "1px solid #374045" }}
                  onKeyDown={(e) => e.key === "Enter" && handleAddContact()}
                />
              </div>

              <div
                className="rounded-xl p-3 text-xs"
                style={{ background: "#1a2730", color: "#8696a0" }}
              >
                💡 Demo: Coba{" "}
                {["+6281111111111", "+6282222222222", "+6283333333333"].map((p) => (
                  <span
                    key={p}
                    className="cursor-pointer font-mono"
                    style={{ color: "#00a884" }}
                    onClick={() => setAddPhone(p)}
                  >
                    {p}{" "}
                  </span>
                ))}
              </div>

              {addError && (
                <p className="text-sm text-red-400 bg-red-900/20 px-3 py-2 rounded-lg">
                  {addError}
                </p>
              )}
              {addSuccess && (
                <p className="text-sm text-green-400 flex items-center gap-2 bg-green-900/20 px-3 py-2 rounded-lg">
                  <Check size={16} /> {addSuccess}
                </p>
              )}

              <button
                onClick={handleAddContact}
                disabled={addLoading || addPhone.length < 10}
                className="w-full py-3 rounded-xl font-semibold text-sm disabled:opacity-50 transition-all"
                style={{ background: "#00a884", color: "white" }}
              >
                {addLoading ? "Mencari..." : "Tambah Kontak"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
