"use client";

export default function WelcomeScreen() {
  return (
    <div
      className="flex flex-col items-center justify-center h-full gap-6"
      style={{
        background: "#0b141a",
        borderLeft: "1px solid #222d34",
      }}
    >
      <div className="text-center max-w-sm px-8">
        <div
          className="w-24 h-24 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 shadow-2xl"
          style={{ background: "#202c33" }}
        >
          💬
        </div>
        <h2
          className="text-3xl font-light mb-3"
          style={{ color: "#e9edef" }}
        >
          LiberChat Web
        </h2>
        <p className="text-sm leading-relaxed mb-6" style={{ color: "#8696a0" }}>
          Kirim dan terima pesan tanpa menyimpan HP Anda online.
          Gunakan LiberChat di mana saja.
        </p>
        <div
          className="rounded-2xl p-4 text-left space-y-3"
          style={{ background: "#182229", border: "1px solid #2a3942" }}
        >
          <p className="text-xs font-semibold" style={{ color: "#00a884" }}>
            ✨ Fitur LiberChat
          </p>
          {[
            "💬 Chat real-time via WebSocket",
            "🔒 Pesan privat antar pengguna",
            "👥 Tambah kontak via nomor HP",
            "✓✓ Indikator baca pesan",
            "⌨️ Indikator sedang mengetik",
            "🟢 Status online/offline kontak",
          ].map((f) => (
            <p key={f} className="text-xs" style={{ color: "#8696a0" }}>
              {f}
            </p>
          ))}
        </div>
        <p className="text-xs mt-4" style={{ color: "#374045" }}>
          🔒 Enkripsi end-to-end. Klik kontak untuk mulai chat.
        </p>
      </div>
    </div>
  );
}
