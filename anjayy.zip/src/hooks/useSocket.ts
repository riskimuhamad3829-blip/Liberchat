"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import type { Message } from "@/types";

interface UseSocketOptions {
  userId: string | null;
  onMessage: (msg: Message) => void;
  onUserOnline: (userId: string) => void;
  onUserOffline: (userId: string) => void;
  onTyping: (senderId: string, isTyping: boolean) => void;
  onMessagesRead: (by: string) => void;
}

export function useSocket({
  userId,
  onMessage,
  onUserOnline,
  onUserOffline,
  onTyping,
  onMessagesRead,
}: UseSocketOptions) {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!userId) return;

    const socket = io(window.location.origin, {
      path: "/api/socket",
      transports: ["websocket", "polling"],
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      socket.emit("join-chat", userId);
    });

    socket.on("disconnect", () => {
      setConnected(false);
    });

    socket.on("receive-message", (msg: Message) => {
      onMessage(msg);
    });

    socket.on("user-online", ({ userId: uid }: { userId: string }) => {
      onUserOnline(uid);
    });

    socket.on("user-offline", ({ userId: uid }: { userId: string }) => {
      onUserOffline(uid);
    });

    socket.on("typing", ({ senderId, isTyping }: { senderId: string; isTyping: boolean }) => {
      onTyping(senderId, isTyping);
    });

    socket.on("messages-read", ({ by }: { by: string }) => {
      onMessagesRead(by);
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
      setConnected(false);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const sendMessage = useCallback(
    (senderId: string, receiverId: string, content: string) => {
      socketRef.current?.emit("send-private-message", {
        senderId,
        receiverId,
        content,
      });
    },
    [],
  );

  const sendTyping = useCallback(
    (senderId: string, receiverId: string, isTyping: boolean) => {
      socketRef.current?.emit("typing", { senderId, receiverId, isTyping });
    },
    [],
  );

  const markRead = useCallback((viewerId: string, senderId: string) => {
    socketRef.current?.emit("mark-read", { viewerId, senderId });
  }, []);

  return { connected, sendMessage, sendTyping, markRead };
}
