// ============================================================
// LiberChat - Custom Next.js Server with Socket.io
// Run: node server.js
// ============================================================
"use strict";

const { createServer } = require("http");
const { parse } = require("url");
const next = require("next");
const { Server: SocketIOServer } = require("socket.io");
const { v4: uuidv4 } = require("uuid");

const dev = process.env.NODE_ENV !== "production";
const hostname = process.env.HOST || "0.0.0.0";
const port = parseInt(process.env.PORT || "3000", 10);

// ── In-Memory Store ─────────────────────────────────────────
const store = {
  users: new Map(),      // userId  → User
  phones: new Map(),     // phone   → userId
  otps: new Map(),       // phone   → OTPRecord
  contacts: [],          // [{ownerId, contactId}]
  messages: [],          // [Message]
  socketMap: new Map(),  // userId  → socketId
};

// ── Seed Data ────────────────────────────────────────────────
const seedUsers = [
  { id: "demo-001", phone: "+6281111111111", name: "Alice (Demo)", avatar: "/default-avatar.png", createdAt: Date.now() },
  { id: "demo-002", phone: "+6282222222222", name: "Bob (Demo)",   avatar: "/default-avatar.png", createdAt: Date.now() },
  { id: "demo-003", phone: "+6283333333333", name: "Charlie (Demo)", avatar: "/default-avatar.png", createdAt: Date.now() },
];
for (const u of seedUsers) {
  store.users.set(u.id, u);
  store.phones.set(u.phone, u.id);
}
store.contacts.push(
  { ownerId: "demo-001", contactId: "demo-002" },
  { ownerId: "demo-001", contactId: "demo-003" },
  { ownerId: "demo-002", contactId: "demo-001" },
  { ownerId: "demo-003", contactId: "demo-001" },
);
const now = Date.now();
store.messages.push(
  { id: "msg-001", senderId: "demo-002", receiverId: "demo-001", content: "Halo! Ini Alice ya? 👋",              timestamp: now - 3_600_000, status: "read" },
  { id: "msg-002", senderId: "demo-001", receiverId: "demo-002", content: "Iya bener! Halo Bob! 😊",              timestamp: now - 3_500_000, status: "read" },
  { id: "msg-003", senderId: "demo-002", receiverId: "demo-001", content: "Udah coba LiberChat belum? Mirip WA!", timestamp: now - 1_800_000, status: "delivered" },
);

// ── Helper ────────────────────────────────────────────────────
function generateOTP() {
  return Math.floor(100_000 + Math.random() * 900_000).toString();
}

// ── Next.js App ──────────────────────────────────────────────
const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const httpServer = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url, true);
      const { pathname } = parsedUrl;

      // ── REST API routes handled here ──────────────────────

      // POST /api/auth/send-otp
      if (pathname === "/api/auth/send-otp" && req.method === "POST") {
        let body = "";
        req.on("data", (chunk) => (body += chunk));
        req.on("end", () => {
          try {
            const { phone } = JSON.parse(body);
            const normalized = (phone || "").replace(/\s+/g, "").trim();
            if (!normalized.startsWith("+62") || normalized.length < 10) {
              res.writeHead(400, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "Nomor HP harus diawali +62 dan minimal 10 digit" }));
            }
            const otp = generateOTP();
            store.otps.set(normalized, { phone: normalized, otp, expiresAt: Date.now() + 60_000, verified: false });
            console.log(`[OTP] ${normalized} → ${otp}`);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true, message: "OTP terkirim (simulasi)", otp, expiresIn: 60 }));
          } catch {
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Server error" }));
          }
        });
        return;
      }

      // POST /api/auth/verify-otp
      if (pathname === "/api/auth/verify-otp" && req.method === "POST") {
        let body = "";
        req.on("data", (chunk) => (body += chunk));
        req.on("end", () => {
          try {
            const { phone, otp, name } = JSON.parse(body);
            const normalized = (phone || "").replace(/\s+/g, "").trim();
            const record = store.otps.get(normalized);
            if (!record) {
              res.writeHead(400, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "OTP tidak ditemukan. Minta OTP baru." }));
            }
            if (Date.now() > record.expiresAt) {
              store.otps.delete(normalized);
              res.writeHead(400, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "OTP kadaluarsa. Minta OTP baru." }));
            }
            if (record.otp !== otp.toString().trim()) {
              res.writeHead(400, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "OTP salah. Coba lagi." }));
            }
            store.otps.delete(normalized);
            let userId = store.phones.get(normalized);
            let isNew = false;
            if (!userId) {
              isNew = true;
              userId = uuidv4();
              const displayName = (name || "").trim() || `User ${normalized.slice(-4)}`;
              const user = { id: userId, phone: normalized, name: displayName, avatar: "/default-avatar.png", createdAt: Date.now() };
              store.users.set(userId, user);
              store.phones.set(normalized, userId);
            }
            const user = store.users.get(userId);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true, isNew, user: { id: user.id, phone: user.phone, name: user.name, avatar: user.avatar } }));
          } catch {
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Server error" }));
          }
        });
        return;
      }

      // GET /api/contacts?userId=xxx
      if (pathname === "/api/contacts" && req.method === "GET") {
        const userId = parsedUrl.query.userId;
        if (!userId) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ error: "userId required" }));
        }
        const contactIds = store.contacts.filter((c) => c.ownerId === userId).map((c) => c.contactId);
        const contacts = contactIds.map((id) => store.users.get(id)).filter(Boolean).map((u) => ({
          id: u.id, phone: u.phone, name: u.name, avatar: u.avatar,
          isOnline: store.socketMap.has(u.id),
        }));
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ contacts }));
      }

      // POST /api/contacts
      if (pathname === "/api/contacts" && req.method === "POST") {
        let body = "";
        req.on("data", (chunk) => (body += chunk));
        req.on("end", () => {
          try {
            const { ownerId, phone } = JSON.parse(body);
            const normalized = (phone || "").replace(/\s+/g, "").trim();
            const targetId = store.phones.get(normalized);
            if (!targetId) {
              res.writeHead(404, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "Nomor HP tidak terdaftar di LiberChat" }));
            }
            if (targetId === ownerId) {
              res.writeHead(400, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "Tidak bisa menambah diri sendiri" }));
            }
            const already = store.contacts.some((c) => c.ownerId === ownerId && c.contactId === targetId);
            if (already) {
              res.writeHead(409, { "Content-Type": "application/json" });
              return res.end(JSON.stringify({ error: "Kontak sudah ada" }));
            }
            store.contacts.push({ ownerId, contactId: targetId });
            const target = store.users.get(targetId);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true, contact: { id: target.id, phone: target.phone, name: target.name, avatar: target.avatar, isOnline: store.socketMap.has(target.id) } }));
          } catch {
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Server error" }));
          }
        });
        return;
      }

      // GET /api/messages?userId=xxx&contactId=yyy
      if (pathname === "/api/messages" && req.method === "GET") {
        const userId = parsedUrl.query.userId;
        const contactId = parsedUrl.query.contactId;
        if (!userId || !contactId) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ error: "userId and contactId required" }));
        }
        const messages = store.messages
          .filter((m) => (m.senderId === userId && m.receiverId === contactId) || (m.senderId === contactId && m.receiverId === userId))
          .sort((a, b) => a.timestamp - b.timestamp);
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ messages }));
      }

      // GET /api/users/search?phone=xxx
      if (pathname === "/api/users/search" && req.method === "GET") {
        const phone = parsedUrl.query.phone;
        if (!phone) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ error: "phone required" }));
        }
        const normalized = phone.replace(/\s+/g, "").trim();
        const userId = store.phones.get(normalized);
        if (!userId) {
          res.writeHead(200, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ found: false, user: null }));
        }
        const user = store.users.get(userId);
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ found: true, user: { id: user.id, phone: user.phone, name: user.name, avatar: user.avatar } }));
      }

      // ── Health check ──────────────────────────────────────
      if (pathname === "/api/health") {
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ status: "ok", app: "LiberChat", users: store.users.size }));
      }

      // ── All other routes → Next.js handler ───────────────
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error("Request error:", err);
      res.writeHead(500);
      res.end("Internal Server Error");
    }
  });

  // ── Socket.io ─────────────────────────────────────────────
  const io = new SocketIOServer(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] },
    path: "/api/socket",
    transports: ["websocket", "polling"],
  });

  io.on("connection", (socket) => {
    console.log("[socket] connected:", socket.id);

    // join-chat: user comes online
    socket.on("join-chat", (userId) => {
      if (!userId) return;
      store.socketMap.set(userId, socket.id);
      socket.join(userId);
      console.log(`[socket] ${userId} joined (${socket.id})`);

      // Notify contacts user is online
      store.contacts.filter((c) => c.ownerId === userId).forEach((c) => {
        const sid = store.socketMap.get(c.contactId);
        if (sid) io.to(sid).emit("user-online", { userId });
      });
    });

    // send-private-message
    socket.on("send-private-message", ({ senderId, receiverId, content }) => {
      if (!senderId || !receiverId || !(content || "").trim()) return;

      const msg = {
        id: uuidv4(),
        senderId,
        receiverId,
        content: content.trim(),
        timestamp: Date.now(),
        status: "sent",
      };
      store.messages.push(msg);

      // Echo to sender
      socket.emit("receive-message", msg);

      // Deliver to receiver
      const receiverSid = store.socketMap.get(receiverId);
      if (receiverSid) {
        msg.status = "delivered";
        io.to(receiverSid).emit("receive-message", msg);
      }
    });

    // mark-read
    socket.on("mark-read", ({ viewerId, senderId }) => {
      store.messages.forEach((m) => {
        if (m.senderId === senderId && m.receiverId === viewerId) m.status = "read";
      });
      const senderSid = store.socketMap.get(senderId);
      if (senderSid) io.to(senderSid).emit("messages-read", { by: viewerId });
    });

    // typing indicator
    socket.on("typing", ({ senderId, receiverId, isTyping }) => {
      const sid = store.socketMap.get(receiverId);
      if (sid) io.to(sid).emit("typing", { senderId, isTyping });
    });

    // disconnect
    socket.on("disconnect", () => {
      for (const [uid, sid] of store.socketMap.entries()) {
        if (sid === socket.id) {
          store.socketMap.delete(uid);
          store.contacts.filter((c) => c.ownerId === uid).forEach((c) => {
            const targetSid = store.socketMap.get(c.contactId);
            if (targetSid) io.to(targetSid).emit("user-offline", { userId: uid });
          });
          console.log(`[socket] ${uid} disconnected`);
          break;
        }
      }
    });
  });

  // ── Start server ──────────────────────────────────────────
  httpServer.listen(port, hostname, () => {
    console.log(`✅ LiberChat server running at http://${hostname}:${port}`);
    console.log(`   Environment: ${dev ? "development" : "production"}`);
    console.log(`   Socket.io  : ws://${hostname}:${port}/api/socket`);
  });
});
